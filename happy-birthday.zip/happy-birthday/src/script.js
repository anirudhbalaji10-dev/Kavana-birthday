// Function to launch confetti from different origins
function launchConfetti(originX, color) {
    confetti({
        particleCount: 120,
        spread: 100,
        origin: { y: 0.6, x: originX },
        colors: color,
        disableForReducedMotion: true
    });
}

// Function to run the full, impressive animation sequence
function runImpressiveConfetti() {
    launchConfetti(0.5, ['#FF69B4', '#FFD700', '#FFFFFF']);
    setTimeout(() => {
        launchConfetti(0.1, ['#ADD8E6', '#C0C0C0', '#FFFFFF']);
    }, 400);
    setTimeout(() => {
        launchConfetti(0.9, ['#FF0000', '#FF1493', '#F5F5DC']);
    }, 800);
}

// --- NEW FUNCTION: Runs when the user "blows" the candle ---
function blowCandle() {
    // 1. Hide the pre-loader
    document.getElementById('preloader').classList.add('hidden');
    
    // 2. Show the main website content
    document.getElementById('main-content').style.display = 'block';

    // 3. Launch the powerful confetti animation!
    runImpressiveConfetti();
}

// Function to run when you click a card
function toggleReveal(cardElement) {
    const hiddenContent = cardElement.querySelector('.reveal-content');
    hiddenContent.classList.toggle('active');

    cardElement.style.transform = 'translateY(-12px) scale(1.03)';
    setTimeout(() => {
        cardElement.style.transform = '';
    }, 200);

    // Launch a small burst of confetti on click for extra fun!
    launchConfetti(0.5, ['#FF69B4']);
}

// Make the functions globally available
window.blowCandle = blowCandle;
window.toggleReveal = toggleReveal;
